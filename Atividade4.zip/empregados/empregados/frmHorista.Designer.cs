﻿namespace empregados
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lblMatriculaH = new System.Windows.Forms.Label();
            this.lblNomeH = new System.Windows.Forms.Label();
            this.lblSalarioH = new System.Windows.Forms.Label();
            this.lblDataH = new System.Windows.Forms.Label();
            this.txtMatriculaH = new System.Windows.Forms.TextBox();
            this.txtNomeH = new System.Windows.Forms.TextBox();
            this.txtSalarioH = new System.Windows.Forms.TextBox();
            this.txtDataH = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(171, 276);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 79);
            this.button1.TabIndex = 0;
            this.button1.Text = "instanciar Horista";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(642, 276);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(157, 79);
            this.button2.TabIndex = 1;
            this.button2.Text = "instanciar horista com parametro";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // lblMatriculaH
            // 
            this.lblMatriculaH.AutoSize = true;
            this.lblMatriculaH.Location = new System.Drawing.Point(184, 49);
            this.lblMatriculaH.Name = "lblMatriculaH";
            this.lblMatriculaH.Size = new System.Drawing.Size(73, 20);
            this.lblMatriculaH.TabIndex = 2;
            this.lblMatriculaH.Text = "Matricula";
            // 
            // lblNomeH
            // 
            this.lblNomeH.AutoSize = true;
            this.lblNomeH.Location = new System.Drawing.Point(184, 95);
            this.lblNomeH.Name = "lblNomeH";
            this.lblNomeH.Size = new System.Drawing.Size(51, 20);
            this.lblNomeH.TabIndex = 3;
            this.lblNomeH.Text = "Nome";
            // 
            // lblSalarioH
            // 
            this.lblSalarioH.AutoSize = true;
            this.lblSalarioH.Location = new System.Drawing.Point(184, 145);
            this.lblSalarioH.Name = "lblSalarioH";
            this.lblSalarioH.Size = new System.Drawing.Size(113, 20);
            this.lblSalarioH.TabIndex = 4;
            this.lblSalarioH.Text = "Salário Mensal";
            this.lblSalarioH.Click += new System.EventHandler(this.label3_Click);
            // 
            // lblDataH
            // 
            this.lblDataH.AutoSize = true;
            this.lblDataH.Location = new System.Drawing.Point(184, 200);
            this.lblDataH.Name = "lblDataH";
            this.lblDataH.Size = new System.Drawing.Size(213, 20);
            this.lblDataH.TabIndex = 5;
            this.lblDataH.Text = "Data de entrada na empresa";
            // 
            // txtMatriculaH
            // 
            this.txtMatriculaH.Location = new System.Drawing.Point(465, 43);
            this.txtMatriculaH.Name = "txtMatriculaH";
            this.txtMatriculaH.Size = new System.Drawing.Size(334, 26);
            this.txtMatriculaH.TabIndex = 6;
            // 
            // txtNomeH
            // 
            this.txtNomeH.Location = new System.Drawing.Point(465, 92);
            this.txtNomeH.Name = "txtNomeH";
            this.txtNomeH.Size = new System.Drawing.Size(334, 26);
            this.txtNomeH.TabIndex = 7;
            // 
            // txtSalarioH
            // 
            this.txtSalarioH.Location = new System.Drawing.Point(465, 139);
            this.txtSalarioH.Name = "txtSalarioH";
            this.txtSalarioH.Size = new System.Drawing.Size(334, 26);
            this.txtSalarioH.TabIndex = 8;
            // 
            // txtDataH
            // 
            this.txtDataH.Location = new System.Drawing.Point(465, 194);
            this.txtDataH.Name = "txtDataH";
            this.txtDataH.Size = new System.Drawing.Size(334, 26);
            this.txtDataH.TabIndex = 9;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(980, 529);
            this.Controls.Add(this.txtDataH);
            this.Controls.Add(this.txtSalarioH);
            this.Controls.Add(this.txtNomeH);
            this.Controls.Add(this.txtMatriculaH);
            this.Controls.Add(this.lblDataH);
            this.Controls.Add(this.lblSalarioH);
            this.Controls.Add(this.lblNomeH);
            this.Controls.Add(this.lblMatriculaH);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblMatriculaH;
        private System.Windows.Forms.Label lblNomeH;
        private System.Windows.Forms.Label lblSalarioH;
        private System.Windows.Forms.Label lblDataH;
        private System.Windows.Forms.TextBox txtMatriculaH;
        private System.Windows.Forms.TextBox txtNomeH;
        private System.Windows.Forms.TextBox txtSalarioH;
        private System.Windows.Forms.TextBox txtDataH;
    }
}